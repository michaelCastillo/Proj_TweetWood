<template>
    <div id="app-footer">
        <v-footer class="pa-3" app color="grey darken-4">
            <v-flex xs12 py-3 text-xs-left white--text>
                2018 — <strong>Grupo Nº1</strong>

            </v-flex>
            <v-btn dark>
                <v-icon dark left>fab fa-facebook</v-icon>
            </v-btn>

            <v-btn dark>
                <v-icon dark left>fab fa-github</v-icon>
            </v-btn>
        </v-footer>
    </div>

</template>

<script>
    export default {
        name: 'app-footer',
    }
</script>